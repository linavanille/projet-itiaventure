select * 
from Lieux;

