select * 
from Lieux

